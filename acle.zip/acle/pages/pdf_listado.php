<?php
include ("../mpdf/mpdf.php");
include_once ("../clases/Alumno.php");


$id = $_GET['id'];

echo  $id;

$html='
<style>
.alinear{
    text-align:center;
    padding-left:0px;
    padding-top:100px;
}

table {
    border-collapse: collapse;
    width: 100%;
    font-style:Calibri;
    
    
  }
  
  table, th, td {
    border: 1px solid black;
  }

  .thead{
      background-color:#0000FF;
      color:white;
  }
</style>



';




function tabla($cid){
	$conexion = new Conexion();
    $conectar =$conexion->conectar();

	$query ="select alumnos.rut, alumnos.primer_nombre ,alumnos.segundo_nombre,alumnos.apellido_paterno,alumnos.apellido_materno,talleres.nombre as tnombre from alumnos
    LEFT JOIN talleres
    ON alumnos.id_taller = talleres.id_taller
    where id_curso_f = '$cid' 
    ORDER BY `apellido_paterno` ASC";

    $consultar = mysqli_query($conectar,$query);

    $tabla="";
    $tabla="<div class='alinear'>";
    $tabla.="<table class='table'>";
    $tabla.='<thead>';
    $tabla.='<tr>';
    $tabla.="<th class='thead'>"."RUT".'</th>';
    $tabla.="<th  class='thead'>APELLIDOS</th>";
    $tabla.="<th class='thead'>"."NOMBRES".'</th>';
    $tabla.="<th class='thead'>"."TALLER".'</th>';
    $tabla.='</tr>';
    $tabla.='</thead>';
    $tabla.='<tbody>';

	while($row=$consultar->fetch_assoc()){
        
        $tabla.='<tr>';
        $tabla.='<th>'.$row['rut'].'</th>';
        $tabla.='<th>'.$row['apellido_paterno'].'   '.$row['apellido_materno'].'</th>';
        $tabla.='<th>'.$row['primer_nombre'].'   '.$row['segundo_nombre'].'</th>';
        $tabla.='<th>'.$row['tnombre'].'</th>';
        $tabla.='</tr>';
        

       
        
    }
    $tabla.='</tbody>';
    $tabla.='</table>'; 
    $tabla.='</div>'; 
	return $tabla;
}










$html.=(tabla($id));

$mpdf = new mPDF('c','A4');
$mpdf->SetImportUse();
$mpdf->SetDocTemplate('../img/forma.pdf',true);
$html = mb_convert_encoding($html, 'UTF-8', 'UTF-8');
$mpdf->allow_charset_conversion=true;
$mpdf->charset_in='UTF-8';
$mpdf->writeHTML($html);

$mpdf->Output('planilla.pdf','I');
