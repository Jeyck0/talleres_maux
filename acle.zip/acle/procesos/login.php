<?php
require_once ("../clases/Conexion.php");

$conexion = new Conexion();
$conexion->conectar();
session_start();

if(isset($_POST["btn_login"])){
    $rut_in = $_POST['rut_in'];
}


$_SESSION['s_id'] = $rut_in;

echo $_SESSION['s_id'];

header("Location:../pages/index.php");


