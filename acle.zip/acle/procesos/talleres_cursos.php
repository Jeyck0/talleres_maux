<?php
require_once ('../clases/Taller.php');

$id_taller = $_GET['id'];
$id_alumno = $_GET['id_alumno'];

$taller = new Taller();
$taller->actualizarTallerAlumno($id_taller,$id_alumno);
$taller-> restarCupo($id_taller);



header("Location:../pages/talleres_cursos.php");