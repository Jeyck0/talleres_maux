$(document).ready(function(){
    $('#btn_inscribir').click(function(){
        $('#miModal').modal("show");
    })
})